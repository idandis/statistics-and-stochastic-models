%% 1) Parte introduttiva: Analisi dei dati
%Caricamento del dataset completo ed eliminazione delle celle prive di
%alcuni valori.
tab = readtable ("dataset.xlsx");
tab = rmmissing(tab);

%% Analisi grafica
%Elaboriamo i grafici tra l'Ozono e gli altri regressori, per avere una
%prima interpretazione riguardante la correlazione tra essi.

%O3 e Tempemperatura
y = tab.Ozono;
x = tab.Temperatura;
scatter(x,y,'filled')
p=polyfit(x,y,1);
fx=polyval(p,x);
hold on
plot(x,fx)
xlabel('Temperatura'); ylabel('Ozono');
title('OZONO E TEMPERATURA') 

%O3 ed Umidità
y = tab.Ozono;
x = tab.Umidit_Relativa;
scatter(x,y,'filled')
p=polyfit(x,y,1);
fx=polyval(p,x);
hold on
plot(x,fx)
xlabel('Umidità relativa'); ylabel('Ozono');
title('OZONO ED UMIDITA') 

%O3 ed Ammoniaca
y = tab.Ozono;
x = tab.Ammoniaca;
scatter(x,y,'filled')
p=polyfit(x,y,1);
fx=polyval(p,x);
hold on
plot(x,fx)
xlabel('Ammoniaca'); ylabel('Ozono');
title('OZONO ED AMMONIACA') 

%O3 e PM2_5
y = tab.Ozono;
x = tab.PM2_5;
scatter(x,y,'filled')
p=polyfit(x,y,1);
fx=polyval(p,x);
hold on
plot(x,fx)
xlabel('PM2_5'); ylabel('Ozono');
title('OZONO E PM2_5')

%O3 e Benzene
y = tab.Ozono;
x = tab.Benzene;
scatter(x,y,'filled')
p=polyfit(x,y,1);
fx=polyval(p,x);
hold on
plot(x,fx)
xlabel('Benzene'); ylabel('Ozono');
title('OZONO E BENZENE') 

%O3 ed NO2
y = tab.Ozono;
x = tab.BiossidoDiAzoto;
scatter(x,y,'filled')
p=polyfit(x,y,1);
fx=polyval(p,x);
hold on
plot(x,fx)
xlabel('Biossido di azoto'); ylabel('Ozono');
title('OZONO E BIOSSIDO DI AZOTO') 

%O3 e Spostamenti in macchina
y = tab.Ozono;
x = tab.SpostamentiInMacchina;
scatter(x,y,'filled')
p=polyfit(x,y,1);
fx=polyval(p,x);
hold on
plot(x,fx)
xlabel('Spostamenti'); ylabel('Ozono');
title('OZONO e SPOSTAMENTI') 

%O3 e PM10
y = tab.Ozono;
x = tab.PM10;
scatter(x,y,'filled')
p=polyfit(x,y,1);
fx=polyval(p,x);
hold on
plot(x,fx)
xlabel('PM10'); ylabel('Ozono');
title('OZONO E PM10') 

%% Vettore delle medie
%Calcoliamo le medie dei nostri regressori: otteniamo così un vettore di
%medie.
X= [tab.BiossidoDiAzoto tab.Benzene tab.PM10 tab.PM2_5 tab.Temperatura tab.Umidit_Relativa tab.SpostamentiInMacchina tab.Ammoniaca];
medie = mean(X);

%% Matrice varianza-covarianza 
%Stima della matrice di varianza-covarianza (empirica)
varcov= cov(X);
%E' ben definita? Proprietà: deve essere semidefinita positiva.
autovalore_minimo = min(eig(varcov))     %autovalore_minimo = 0.3261
%Tutti gli autovalori devono essere strettamente positivi.La nostra è ben
%definita e valida.

%% 2)Regressione multipla: Stepwise
%Creazione del modello di regressione lineare adattato alle variabili nel set di dati
model = fitlm (tab,'ResponseVar','Ozono','PredictorVars',{'Temperatura','SpostamentiInMacchina','Umidit_Relativa','Ammoniaca','PM10', 'PM2_5','Benzene','BiossidoDiAzoto'})
%Otteniamo un R2=0.892

%STEPWISE AUTOMATICA: creazione di un modello lineare e aggiunge o ritaglia automaticamente il modello.
m_auto= stepwiselm(tab,'ResponseVar','Ozono','PredictorVars',{'Temperatura','SpostamentiInMacchina','Umidit_Relativa','Ammoniaca','PM10', 'PM2_5','Benzene','BiossidoDiAzoto'});

%STEPWISE MANUALE: cerchiamo di simulare il comando automatico, tramite
%l'inserimento/eliminazione ,dei regressori, manuale.

%Tolgo umidità relativa-- R2=0.785
m1= fitlm (tab,'ResponseVar','Ozono','PredictorVars',{'Temperatura','SpostamentiInMacchina','Ammoniaca','PM10', 'PM2_5','Benzene','BiossidoDiAzoto'});
%Aggiungo umidità relativa, tolgo spostamenti in macchina--R2=0.869
m1= fitlm (tab,'ResponseVar','Ozono','PredictorVars',{'Temperatura','Umidit_Relativa','Ammoniaca','PM10', 'PM2_5','Benzene','BiossidoDiAzoto'});
%Tolgo biossido di azoto--R2=0.816
m1= fitlm (tab,'ResponseVar','Ozono','PredictorVars',{'Temperatura','Umidit_Relativa','Ammoniaca','PM10', 'PM2_5','Benzene'});
%Aggiungo biossido di azoto e tolgo il benzene --R2=0.867
m1= fitlm (tab,'ResponseVar','Ozono','PredictorVars',{'Temperatura','Umidit_Relativa','Ammoniaca','PM10', 'PM2_5','BiossidoDiAzoto'});
%Aggiungo gli spostamenti in macchina--R2=0.891
m1= fitlm (tab,'ResponseVar','Ozono','PredictorVars',{'Temperatura','SpostamentiInMacchina','Umidit_Relativa','Ammoniaca','PM10', 'PM2_5','BiossidoDiAzoto'});
%Tolgo ammoniaca--R2=0.891
m1= fitlm (tab,'ResponseVar','Ozono','PredictorVars',{'Temperatura','SpostamentiInMacchina','Umidit_Relativa','PM10', 'PM2_5','BiossidoDiAzoto'});
%Aggiungo ammoniaca e tolgo PM2_5--R2=0.888
m1= fitlm (tab,'ResponseVar','Ozono','PredictorVars',{'Temperatura','SpostamentiInMacchina','Umidit_Relativa','Ammoniaca','PM10','BiossidoDiAzoto'});
%Aggiungo PM2_5 e tolgo PM_10--R2=0.890
m1= fitlm (tab,'ResponseVar','Ozono','PredictorVars',{'Temperatura','SpostamentiInMacchina','Umidit_Relativa','Ammoniaca','PM2_5','BiossidoDiAzoto'});
%Tolgo la temperatura--R2=0.846
m1= fitlm (tab,'ResponseVar','Ozono','PredictorVars',{'SpostamentiInMacchina','Umidit_Relativa','Ammoniaca','PM2_5','BiossidoDiAzoto'})

%Il migliore modello ottenuto manualmente risulta:
m_manuale= fitlm (tab,'ResponseVar','Ozono','PredictorVars',{'Temperatura','SpostamentiInMacchina','Umidit_Relativa','Ammoniaca','PM10', 'PM2_5','BiossidoDiAzoto'});
%Qui ho un R2=0.891 molto vicino ad R2=0.909 trovato usando la stepwise automatica


%% 2)Regressione multipla: Stima dei coefficienti
%Calcolo numero delle osservazioni dei regressori
n1=numel(tab.Ozono);
n2=numel(tab.Temperatura);
n3=numel(tab.SpostamentiInMacchina);
n4=numel(tab.Umidit_Relativa);
n5=numel(tab.Ammoniaca);
n6=numel(tab.PM10);
n7=numel(tab.PM2_5);
n8=numel(tab.Benzene);
n9=numel(tab.BiossidoDiAzoto);
n=n1;

%Calcolo delle devianze
model.SSE;                   %Devianza residua
model.SST;                   %Devianza totale
model.SSR;                   %Devianza di regressione

%Calcolo delle varianze
s2_e = model.SSE/(n-8-1)     %Varianza residua
s2_sp = model.SSR/(n-8-1)    %Varianza spiegata
s2_tot = model.SST/(n-8-1);  %Varianza totale

%Coefficiente di determinazione: calcolo manuale
R2=1-(model.SSE/model.SST)

%Coefficiente di determinazione corretto
R2_corr= 1- ((n-1)/(n-8-1))*(model.SSE/model.SST)

%Coefficiente di correlazione R: è la radice quadrata di R^2
R=sqrt(R2)

%Calcolo i coefficienti beta e l'IC
beta_hat = model.Coefficients.Estimate
beta_hatIC = model.coefCI;

%% 2)Regressione multipla: TEST-T sui coefficienti
%Biossido di azoto
t_beta1 = model.Coefficients.tStat(2);
alpha = 0.05;
t_oss = t_beta1;
t_crit1 = - tinv(1-alpha/2,n-8-1);
t_crit1 = + tinv(1-alpha/2,n-8-1);
pv_t_beta1 = model.Coefficients.pValue(2);

%Benzene
t_beta2 = model.Coefficients.tStat(3);
alpha = 0.05;
t_oss = t_beta2;
t_crit2 = - tinv(1-alpha/2,n-8-1);
t_crit2 = + tinv(1-alpha/2,n-8-1);
pv_t_beta1 = model.Coefficients.pValue(3);

%PM10
t_beta3 = model.Coefficients.tStat(4);
alpha = 0.05;
t_oss = t_beta3;
t_crit3 = - tinv(1-alpha/2,n-8-1);
t_crit3 = + tinv(1-alpha/2,n-8-1);
pv_t_beta1 = model.Coefficients.pValue(4);

%PM2_5
t_beta4 = model.Coefficients.tStat(5);
alpha = 0.05;
t_oss = t_beta4;
t_crit4 = - tinv(1-alpha/2,n-8-1);
t_crit = + tinv(1-alpha/2,n-8-1);
pv_t_beta1 = model.Coefficients.pValue(5);

%Temperatura
t_beta5 = model.Coefficients.tStat(6);
alpha = 0.05;
t_oss = t_beta5;
t_crit5 = - tinv(1-alpha/2,n-8-1);
t_crit5 = + tinv(1-alpha/2,n-8-1);
pv_t_beta1 = model.Coefficients.pValue(6);

%Umidità
t_beta6 = model.Coefficients.tStat(7);
alpha = 0.05;
t_oss = t_beta6;
t_crit6 = - tinv(1-alpha/2,n-8-1);
t_crit6 = + tinv(1-alpha/2,n-8-1);
pv_t_beta1 = model.Coefficients.pValue(7);

%Spostamenti
t_beta7 = model.Coefficients.tStat(8);
alpha = 0.05;
t_oss = t_beta7;
t_crit7 = - tinv(1-alpha/2,n-8-1);
t_crit7 = + tinv(1-alpha/2,n-8-1);
pv_t_beta1 = model.Coefficients.pValue(8);

%Ammoniaca
t_beta8 = model.Coefficients.tStat(9);
alpha = 0.05;
t_oss = t_beta8;
t_crit8 = - tinv(1-alpha/2,n-8-1);
t_crit8 = + tinv(1-alpha/2,n-8-1);
pv_t_beta1 = model.Coefficients.pValue(9);


%% 2)Regressione multipla: ANALISI DEI RESIDUI
%Calcolo dei residui
residui = model.Residuals.Raw;
mean(residui);

%Grafico elementare con la media dei residui
plot(residui)
histfit(residui);
normplot(residui);

%Utilizzo di jbtest 
h = jbtest(residui) 

%Controllo di skewness e curtosi-- se si parla di una normale avremo sk=0 ed
%k=3
sk = skewness(residui)
k = kurtosis(residui)

%Utilizzo del test Lilliefors:risultato sarà uguale a 1 se il test rifiuta l'ipotesi nulla
%al livello di significatività del 5% , e 0 altrimenti. 
l = lillietest(residui)         %Accettiamo l'ipotesi nulla: normalità dei residui

%Verifica dell'omoschedasticita dei residui
%Confronto tra residui e temperatura
temp = [tab.Temperatura];
scatter (temp, residui)
title('Confronto tra residui e temperatura')
ylabel('Residui')
xlabel('Temperatura')

%Confronto tra residui e benzene 
benzene = [tab.Benzene];
scatter (benzene, residui)
title('Confronto tra residui e benzene')
ylabel('Residui')
xlabel('Benzene')

%Confronto tra residui e ozono
ozono = [tab.Ozono];
scatter (ozono, residui)
title('Confronto tra residui e ozono')
ylabel('Residui')
xlabel('Ozono')

%% 3)Tecniche di regressione avanzata: Minimi Quadrati pesati
x=tab.Temperatura;
y=tab.Ozono;
scatter (x,y);

X=[ones(length(x),1) x];
beta = (X'*X)^-1*X'*y;

%Scelta dei pesi mediante algoritmo iterativo
figure
mi = min(x);
ma = max(x);
xx = mi:0.01:ma;
yy=xx*beta(2)+beta(1);
D=ones(length(x),1);

%Prima iterazione: do per scontato che i dati giusti siano quelli iniziali 
plot(xx,yy)
hold on
last_beta=[0 0]'; % all'inizio è uguale a zero ma poi mi salva il valore dell'ultimo beta
exit=0;
iteration_count=1;
while exit==0
    DD(iteration_count,:)=D;
    D = diag(D);
    beta = inv(X'*inv(D)*X)*X'*inv(D)*y; 
    res = y - (beta(1)+beta(2)*x);          %criterio del risiduo 
    D = abs(res)'+0.001;                    %sommo una quantità piccola al valore assoluto per non avere problemi di segno 
    yy=xx*beta(2)+beta(1);
    plot(xx,yy)
    y1=yy;
    %Calcolo della distanza
    delta=norm(last_beta-beta);
    if delta<0.001
        exit=1;
    end
    iteration_count=iteration_count+1;
    last_beta=beta;
end
totale = iteration_count; %Iterazioni eseguite: 28

%Matrice dei pesi delle simulazioni
DD;
omega = diag(DD(end,:));
b_hat_omega_ls = last_beta;
figure
plot(x,y,'o')
hold on
retta=b_hat_omega_ls(1)+x*b_hat_omega_ls(2);
plot(x,retta) 
title('Minimi quadrati ponderati')
xlabel('Temperatura')
ylabel('Ozono')


%% 4) Spline con funzioni di base di Fourier sulla temperatura
% Vettore di dati continuo nel tempo (senza Nan)
tab = readtable ("temperature.xlsx");
Temperature=tab.Temperatura;
Temperature = rmmissing(Temperature);   % eliminazione Nan
Temperature = Temperature(1 : 240);     % seleziono un periodo di 10 giorni
Temperature = Temperature + 273.15;     % trasformo da C° in Kelvin

% Plot della temperatura
figure('Name','Temperatura nel tempo')
plot(Temperature)                       % si nota l'andamento periodico della temperatura

% parametri del vettore temperatura
n = length(Temperature);                % numero di osservazioni
t = 1:n;                                % vettore del tempo
T = length(Temperature)/10;             % periodo pari ad un giorno
f = 1/T;                                % frequenza = 1 / periodo
w = 2*pi/T;                             % pulsazione = 2 * pi / periodo
range_value = [min(t), max(t)];         % vettore di inizio e fine misurazione

% determinazione n_basis tramite General Cross-Validation (GCV)
n_max_basis = 10;
GCV = zeros(n_max_basis,1);
for order = 1 : n_max_basis
    
    % creazione basi di Fourier
    m = order - 1;                      % numero di basi senza la costante
    n_basis_temp = 2*m + 1;             % numero di basi di Fourier
    basis = create_fourier_basis(range_value,n_basis_temp,T);
    
    % valutazione delle basi nel tempo
    phi = full(eval_basis(t,basis));
    
    % parametri regressione lineare
    Cmap = (phi' * phi) \ (phi');       % Cmap
    c_hat = Cmap * Temperature;         % vettore delle stime dei coefficienti
    S = phi * Cmap;                     % matrice di smoothing
    y_hat = phi * c_hat;                % osservazioni stimate
    
    % calcolo dei residui e SSE
    res = Temperature - y_hat;          % vettore dei residui
    SSE = res' * res;                   %v SSE
    
    % calcolo della statistica GCV
    GCV(order) = (1/n) * SSE / ((1 - (trace(S)/n))^2);
end
clear order m;

% il numero di basi ottimale minimizza la statistica GCV
order = find(GCV == min(GCV));
m = order - 1;
n_basis = 2*m + 1;

% creazione e plot basi
basis = create_fourier_basis(range_value,n_basis,T);
figure('Name','Funzioni di base')
plot(basis)

% valutazione delle funzioni nel tempo e plot
basis_mat = full(eval_basis(t,basis));              % matrice phi
figure('Name','Funzioni di base nel dominio delle osservazioni')
plot(t,basis_mat)

% parametri regressione lineare
Cmap  = (basis_mat' * basis_mat) \ (basis_mat');    % Cmap
c_hat = Cmap*Temperature;                           % vettore dei coefficienti delle funzioni basi
S = basis_mat * Cmap;                               % matrice di smoothing
y_hat = basis_mat*c_hat;                            % osservazioni stimate

% plot osservazioni e osservazioni stimate
plot1 = figure('Name','Funzione stimata e misure reali')
plot(t,Temperature,'black.-');
hold on
plot(t,y_hat,'red')
xlabel('osservazioni')
ylabel('valori stimati')
legend('valori rumorosi', 'funzione stimata dai valori rumorosi')


%% 5) CROSS-VALIDAZIONE
%Preparazione di quanto necessario per l'algoritmo iterattivo
MSE = nan(6,1);
R2 = nan(6,1);
tab = readtable ("dataset.xlsx");
tab = rmmissing(tab);

regr_to_add =[{'PM10'} {'PM2_5'} {'Temperatura'} {'Umidit_Relativa'} {'SpostamentiInMacchina'} {'Ammoniaca'}];

for num_regr = 1:length(regr_to_add)
    all_data = rmmissing([ ...
        tab.Ozono, ...
        tab.BiossidoDiAzoto, ...
        tab.Benzene, ...
        table2array(tab(:, regr_to_add(1:num_regr))) ...
    ]);

    y = all_data(:, 1); 
    X = [ones(size(all_data , 1), 1), all_data(:, 2:end)];
    b = (X' * X) \ X' * y;
    y_hat = X * b;
    res = y - y_hat;
    
    % Caratteristiche del modello
    SST = sum((y - mean(y)).^2);
    SSE = sum(res.^2);
    R2(num_regr) = 1 - SSE / SST;

    % Crossval
    regf=@(XTRAIN,ytrain,XTEST)(XTEST*regress(ytrain,XTRAIN));
    MSE(num_regr) = crossval('mse', X, y, 'Predfun', regf);

end

%Grafici di quanto osservato
figure('Name', 'R squared ed MSE')

subplot(1,2,1)
plot(3:8, R2, 'o-')
title('R squared')
ylabel('Percentuale')
xlabel('Numero regressori')

set(gca, 'XTick', 3:8)
subplot(1,2,2)
plot(3:8, MSE, 'o-')
title('Mean Square Error')
xlabel('Numero regressori')
set(gca, 'XTick', 3:8)
axis([3 8 0 1000])

%% 6) Dataset di validazione
%Simuliamo 160 osservazioni della temperatura, nel range opportuno
% dato da [limite superiore,limite inferiore]
x1=tab.Temperatura;
maxtemp= max(x1);                           %Temperatura massima=limite superiore
mintemp= min(x1);                           %Temperatura minima=limite inferiore
T=mintemp + (maxtemp-mintemp)*rand(160,1);   %Vettore colonna di 160 dati

%Analogamente simuliamo 160 osservazioni del biossido di azoto, nel range opportuno
x2=tab.BiossidoDiAzoto;
maxb= max(x2);
minb= min(x2);
B=minb + (maxb-minb)*rand(160,1);

%Simuliamo 160 osservazioni del Benzene
x3=tab.Benzene;
maxbenz=max(x3);
minbenz= min(x3);
BENZ=minbenz + (maxbenz-minbenz)*rand(160,1);

%Simuliamo 160 osservazioni del PM10
x4=tab.PM10;
max10=max(x4);
min10= min(x4);
PM10=min10 + (max10-min10)*rand(160,1);

%Simuliamo 160 osservazioni del PM2_5
x5=tab.PM2_5;
max25= max(x5);
min25= min(x5);
PM25=min25 + (max25-min25)*rand(160,1);

%Simuliamo 160 osservazioni degli spostamenti in macchina
x6=tab.SpostamentiInMacchina;
maxs= max(x6);
mins= min(x6);
S=mins + (maxs-mins)*rand(160,1);

%Simuliamo 160 osservazioni della temperatura, nel range opportuno
x7=tab.Ammoniaca;
maxa= max(x7);
mina= min(x7);
A=mina + (maxa-mina)*rand(160,1);

%Simuliamo 160 osservazioni dell'umidità relativa
x8=tab.Umidit_Relativa;
maxu= max(x8);
minu= min(x8);
U=minu + (maxu-minu)*rand(160,1);

%Unisco tutti i regressori in una unica matrice
X=[B BENZ PM10 PM25 T U S A];

%Utilizzo i coefficienti stimati dal modello di regressione, per ottenere
%una previsione sui valori di y ottenuti sulla base dei dati simulati
model = fitlm (tab,'ResponseVar','Ozono','PredictorVars',{'Temperatura','SpostamentiInMacchina','Umidit_Relativa','Ammoniaca','PM10', 'PM2_5','Benzene','BiossidoDiAzoto'});
b=model.Coefficients.Estimate;
b=b';
Y=b(1)+ b(2)*B + b(3)*BENZ+ b(4)*PM10 + b(5)*PM25 + b(6)*T + b(7)*U + b(8)*S +b(9)*A;

%Grafico di confronto tra i valori di ozono misurati e quelli ottenuti
%tramite simulazione dei valori dei regressori
x=0:1:159;
plot(x,Y)
hold on
plot(x,tab.Ozono)
